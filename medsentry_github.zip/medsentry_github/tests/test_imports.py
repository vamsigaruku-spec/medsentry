def test_project_files_exist():
    from pathlib import Path
    assert Path("app.py").exists()
    assert Path("medsentry/rag/pipeline.py").exists()
    assert Path("medsentry/api/main.py").exists()
    assert Path("medsentry/data/knowledge_base.json").exists()
