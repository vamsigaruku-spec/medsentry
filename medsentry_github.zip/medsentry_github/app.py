"""Streamlit Cloud entry point for MedSentry."""
from medsentry.ui.app import *  # noqa: F401,F403
